Bouncing-Passion

Author: Pellicus
Category: 256 Bytes Intro (Fantasy Console)
System: Tic-80
Description: 
After the endless passions ... just my favourite one.. amigaaaaa boing boing boing ...

Comments:
- a very big Thanks to my beloved Vix who supports me all the time
- thank you superogue and the lovebyte staff ... i love you guys.
- pakettic was used, thank you pestis!
